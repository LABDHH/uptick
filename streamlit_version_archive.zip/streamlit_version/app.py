"""Uptick: Streamlit UI.

No password gate: the app is open. The per-session query cap and the global
quota ledger (cache.quota_ledger) are what protect the daily search-call
budget, and both are enforced silently rather than shown to the user.
"""
from __future__ import annotations

import asyncio
import json
import os
import uuid
from datetime import datetime

import streamlit as st
from langgraph.checkpoint.sqlite.aio import AsyncSqliteSaver

import cache
import demo_data
import graph as graph_mod
import metrics
import theme
import youtube
from theme import bar, chip, esc, ev_row, stat

SESSION_QUERY_CAP = 5
# LangGraph checkpoints let a failed run resume without re-spending search
# calls. They accumulate fast (~1MB/run), so the file is pruned on startup and
# its location is overridable for deployments with a real disk.
CHECKPOINT_DB = os.environ.get("UPTICK_CHECKPOINTS", "checkpoints.db")

st.set_page_config(
    page_title="Uptick",
    page_icon="📈",
    layout="centered",
    initial_sidebar_state="collapsed",
)


# ---------------------------------------------------------------- secrets

def secret(name: str) -> str | None:
    try:
        return st.secrets[name]
    except Exception:
        return None


# ---------------------------------------------------------------- banners

def standing_banners(intent: dict | None) -> None:
    """The structural limits.

    These stay permanently available rather than being shown once and
    dismissed. They are properties of the data, not warnings, and they sit
    below the search box so they inform without dominating the first screen.
    """
    with st.expander("What this data can and cannot tell you"):
        st.markdown(
            '<div class="cm-banner cm-fine">'
            'Geography is <b>country-level only</b>, YouTube exposes no state '
            'or city data. <b>No audience demographics exist</b> publicly, so '
            'nothing here describes viewer age, gender or income. Engagement '
            'is a <b>proxy for attention, not predicted ROI</b>. Sponsorship '
            'disclosure is <b>self-declared and under-reported</b>, so absence '
            'of evidence is not evidence a creator takes no deals.'
            '</div>',
            unsafe_allow_html=True,
        )
    if intent and intent.get("geo_granularity") == "sub_country":
        st.markdown(
            f'<div class="cm-banner warn">'
            f'<b>Sub-country targeting is not available.</b> You asked for '
            f'<b>{esc(intent.get("geo_raw"))}</b>, which is narrower than a '
            f'country. The search ran at country level '
            f'(<b>{esc(intent.get("region_code"))}</b>) and used language and '
            f'content signals as a rough proxy. Treat sub-country fit as '
            f'unverified.</div>',
            unsafe_allow_html=True,
        )


# ---------------------------------------------------------------- run

async def run_query(brief: str, yt_key: str, gem_key: str, status) -> dict:
    """Drive the graph with astream so progress renders as it happens.

    At ~50-60s cold, a progressive render instead of a blank spinner is not a
    nicety. The AsyncSqliteSaver checkpoint means a failed run can be resumed
    without re-spending search calls.
    """
    run_id = uuid.uuid4().hex[:12]

    labels = {
        "interpret": "Reading the brief",
        "strategize": "Planning the search",
        "discover": "Searching YouTube (2 search calls)",
        "enrich": "Fetching channels and recent uploads",
        "dossier": "Compressing candidate dossiers",
        "relevance": "Judging content relevance",
        "audience": "Estimating purchase intent",
        "safety": "Auditing brand safety",
        "sponsorship": "Analysing sponsorship history",
        "cultural": "Researching cultural standing on the web",
        "score": "Scoring and ranking",
        "narrate": "Writing rationales",
        "audit": "Verifying every claim",
    }

    final: dict = {"agent_failures": [], "notices": []}
    async with AsyncSqliteSaver.from_conn_string(CHECKPOINT_DB) as saver:
        g = graph_mod.build_graph(yt_key, gem_key, checkpointer=saver)
        async for chunk in g.astream(
            {"brief_raw": brief, "run_id": run_id, "agent_failures": [], "notices": []},
            config={"configurable": {"thread_id": run_id}},
        ):
            for node, update in chunk.items():
                if node in labels:
                    status.update(label=labels[node])
                if isinstance(update, dict):
                    for k, v in update.items():
                        if k in ("agent_failures", "notices"):
                            final[k] = final.get(k, []) + list(v or [])
                        else:
                            final[k] = v
    return final


# ---------------------------------------------------------------- render

def fmt_int(n) -> str:
    if n is None:
        return "-"
    n = int(n)
    if n >= 1_000_000:
        return f"{n/1_000_000:.1f}M"
    if n >= 1_000:
        return f"{n/1_000:.1f}K"
    return str(n)


def fmt_pct(x) -> str:
    return "-" if x is None else f"{x*100:.2f}%"


CONF_LABEL = {
    "high": ("High confidence", "good"),
    "medium": ("Medium confidence", ""),
    "low": ("Low confidence", "warn"),
}

MATCH_LABEL = {
    "direct": "Direct match",
    "adjacent": "Adjacent niche",
    "lifestyle": "Lifestyle overlap",
    "weak": "Weak fit",
}


RANK_CLASS = {1: "cm-gold", 2: "cm-silver", 3: "cm-bronze"}

FAME_LABEL = {
    "household_name": "Household name",
    "scene_famous": "Famous in their scene",
    "niche_known": "Known in their niche",
}
GEN_LABEL = {
    "gen_z": "Gen Z audience",
    "millennial": "Millennial audience",
    "mixed": "Mixed ages",
    "older": "Older audience",
}


def score_class(v: float) -> str:
    return "s-hi" if v >= 70 else ("s-mid" if v >= 45 else "s-lo")


def row_header(rank: int, r: dict) -> str:
    """Collapsed summary: rank, identity, chips, score, segmented meter."""
    m, conf = r["metrics"], r["confidence"]
    conf_text, conf_kind = CONF_LABEL.get(conf, ("", ""))

    subs = ("Subscribers hidden" if m["subscribers_hidden"]
            else f"{fmt_int(m['subscriber_count'])} subs")
    bits = [subs, f"{fmt_int(m['median_views'])} median views"]
    if m["engagement_rate"] is not None:
        bits.append(f"{fmt_pct(m['engagement_rate'])} engagement")

    chips = [chip(conf_text, conf_kind)]
    cul = r.get("cultural") or {}
    if cul.get("evidence_found"):
        tier = FAME_LABEL.get(cul.get("fame_tier"))
        if tier:
            chips.append(chip(tier, "good"))
        gen = GEN_LABEL.get(cul.get("audience_generation"))
        if gen:
            chips.append(chip(gen, "accent"))
    if r.get("trending"):
        chips.append(chip("Trending today", "accent"))
    if m["paid_placement_hits"]:
        chips.append(chip(f"{m['paid_placement_hits']} declared paid promo", "good"))
    if r["agent"].get("safety_flag"):
        sev = r["agent"].get("safety_severity", "low")
        chips.append(chip(f"Safety: {sev}", "bad" if sev == "high" else "warn"))
    if r.get("partial"):
        chips.append(chip("Partial", "warn"))

    # Meter splits the base score from the bonuses that lifted it.
    total = min(100.0, r["fit_score"])
    bonus = min(total, (r.get("cultural_bonus") or 0)
                + (metrics.TRENDING_BONUS if r.get("trending") else 0))
    base = max(0.0, total - bonus)
    meter = (
        f'<i style="flex:{base:.2f}"></i>'
        + (f'<i class="bonus" style="flex:{bonus:.2f}"></i>' if bonus > 0 else "")
        + f'<i class="rest" style="flex:{max(0.01, 100 - total):.2f}"></i>'
    )

    return (
        f'<div class="cm-rowhead">'
        f'  <div class="cm-rank {RANK_CLASS.get(rank, "")}">{rank}</div>'
        f'  <div class="cm-ident">'
        f'    <div class="cm-name">{esc(r["title"])}</div>'
        f'    <div class="cm-sub">{esc(" · ".join(bits))}</div>'
        f'  </div>'
        f'  <div class="cm-score"><b class="{score_class(r["fit_score"])}">'
        f'{r["fit_score"]:.0f}</b><span>/100</span></div>'
        f'</div>'
        f'<div class="cm-meter">{meter}</div>'
        f'<div class="cm-chips" style="margin-top:.6rem">{"".join(chips)}</div>'
    )


def cultural_block(r: dict) -> str:
    """What the web knows that YouTube does not."""
    cul = r.get("cultural") or {}
    if not cul.get("evidence_found"):
        return ""
    bonus = r.get("cultural_bonus") or 0
    parts = []
    if cul.get("persona"):
        parts.append(f'<em>{esc(cul["persona"])}</em>')
    if cul.get("notable_context"):
        parts.append(esc(cul["notable_context"]))
    if cul.get("brand_fit_note"):
        parts.append(esc(cul["brand_fit_note"]))
    dur = str(cul.get("sustained_or_spike", "")).replace("_", " ")
    return (
        f'<div class="cm-cult"><div class="t">'
        f'<span>Cultural standing · {esc(dur)}</span>'
        f'<span>+{bonus:.1f} pts</span></div>'
        f'<div class="b">{" ".join(parts)}</div></div>'
    )


def render_row(rank: int, r: dict) -> None:
    m, a = r["metrics"], r["agent"]

    st.markdown(
        f'<div class="cm-card cm-joined">{row_header(rank, r)}'
        f'{cultural_block(r)}</div>',
        unsafe_allow_html=True,
    )

    with st.expander("Score breakdown, evidence and recent videos"):
        if r.get("rationale_status") == "verified":
            cav = (f'<div class="c"><span>⚠</span><span>{esc(r["caveat"])}</span></div>'
                   if r.get("caveat") else "")
            st.markdown(
                f'<div class="cm-quote"><div class="h">{esc(r.get("headline",""))}</div>'
                f'<div class="b">{esc(r.get("rationale",""))}</div>{cav}</div>',
                unsafe_allow_html=True,
            )
        elif r.get("rationale_status") == "withheld_unverified":
            claims = r.get("unsupported_claims") or []
            extra = f' Unsupported: {esc("; ".join(claims))}.' if claims else ""
            st.markdown(
                f'<div class="cm-strip"><b>Rationale withheld.</b> The auditor '
                f'could not verify every claim in it, so it was dropped rather '
                f'than shown. The measured breakdown is unaffected.{extra}</div>',
                unsafe_allow_html=True,
            )
        elif r.get("rationale_status") == "withheld_unaudited":
            st.markdown(
                '<div class="cm-strip"><b>Rationale suppressed.</b> The '
                'verification pass did not run, and unaudited prose is never '
                'shown.</div>',
                unsafe_allow_html=True,
            )

        vps = "-" if m["view_per_sub"] is None else f"{m['view_per_sub']:.2f}"
        cons = "-" if m["consistency"] is None else f"{m['consistency']*100:.0f}%"
        st.markdown(
            '<div class="cm-stats">'
            + stat("Median views", fmt_int(m["median_views"]))
            + stat("Engagement", fmt_pct(m["engagement_rate"]),
                   dim=m["engagement_rate"] is None)
            + stat("Views / sub", vps, dim=m["view_per_sub"] is None)
            + stat("Consistency", cons, dim=m["consistency"] is None)
            + "</div>",
            unsafe_allow_html=True,
        )

        left, right = st.columns([1, 1], gap="large")

        with left:
            bars = "".join(
                bar(b["term"].replace("_", " "),
                    b["contribution"] / max(1e-9, r["fit_score"]),
                    f'{b["contribution"]:.1f}')
                for b in r["breakdown"]
            )
            extras = ""
            if r.get("trending"):
                extras += bar("trending bonus",
                              metrics.TRENDING_BONUS / max(1e-9, r["fit_score"]),
                              f"{metrics.TRENDING_BONUS:.1f}")
            if r.get("cultural_bonus"):
                extras += bar("cultural bonus",
                              r["cultural_bonus"] / max(1e-9, r["fit_score"]),
                              f'{r["cultural_bonus"]:.1f}')
            st.markdown(
                f'<div class="cm-panel"><div class="cm-sec">Score breakdown · '
                f'points of {r["fit_score"]:.0f}</div>'
                f'<div class="cm-bars">{bars}{extras}</div></div>',
                unsafe_allow_html=True,
            )
            if r.get("dropped_terms"):
                dropped = ", ".join(t.replace("_", " ") for t in r["dropped_terms"])
                st.markdown(
                    f'<div class="cm-note" style="margin-top:.6rem">'
                    f'Unmeasurable here and renormalized out: {esc(dropped)}.</div>',
                    unsafe_allow_html=True,
                )

        with right:
            rows = []
            if a.get("relevance_reason"):
                mt = MATCH_LABEL.get(a.get("match_type"), a.get("match_type") or "-")
                rows.append(ev_row(mt, esc(a["relevance_reason"])))
            if a.get("inferred_viewer_profile"):
                rows.append(ev_row(
                    f'Likely viewers · {esc(a.get("purchase_intent_signal","-"))} intent',
                    f'{esc(a["inferred_viewer_profile"])} '
                    f'<em style="color:var(--cm-faint);font-weight:500">(inferred '
                    f'from content, not measured)</em>'))
            fmt = a.get("observed_format")
            if fmt and fmt != "none_observed":
                ev = a.get("sponsor_evidence") or ""
                rows.append(ev_row(
                    f'Sponsorships · {esc(fmt.replace("_"," "))} · '
                    f'{esc(a.get("cadence","-"))}',
                    f'“{esc(ev)}”' if ev else "-"))
            else:
                rows.append(ev_row(
                    "Sponsorships",
                    "None observed in the sampled videos. Disclosure is "
                    "self-declared, so this is not evidence they decline deals."))
            if a.get("safety_flag"):
                rows.append(ev_row(
                    f'Safety · {esc(a.get("safety_severity","low"))} · '
                    f'{esc(a.get("safety_category","-"))}',
                    esc(a.get("safety_reason") or "")))
            st.markdown(
                f'<div class="cm-panel"><div class="cm-sec">Evidence</div>'
                f'<div class="cm-ev">{"".join(rows)}</div></div>',
                unsafe_allow_html=True,
            )

        if r.get("top_videos"):
            vids = "".join(
                f'<div class="cm-vid">'
                f'<a href="{esc(v["url"])}" target="_blank">{esc(v["title"])}</a>'
                f'<span class="n">{fmt_int(v["views"])} views'
                f'{" · 💰" if v.get("paid_placement") else ""}</span></div>'
                for v in r["top_videos"]
            )
            st.markdown(
                '<div class="cm-panel"><div class="cm-sec">Recent long-form '
                f'videos</div>{vids}</div>',
                unsafe_allow_html=True,
            )

        st.link_button("Open channel on YouTube  ↗", r["url"])


# ---------------------------------------------------------------- main

@st.cache_resource
def _startup() -> bool:
    """Runs once per container, not per rerun."""
    cache.init_db()
    try:
        cache.prune()
        _prune_checkpoints()
    except Exception:
        pass  # housekeeping must never block the app
    return True


def _prune_checkpoints() -> None:
    """Checkpoints are only useful for resuming a recent failed run."""
    if not os.path.exists(CHECKPOINT_DB):
        return
    # Cheapest correct thing: if it has grown past a sane size, start fresh.
    # Losing old checkpoints costs nothing, they are resume state, not data.
    if os.path.getsize(CHECKPOINT_DB) > 50 * 1024 * 1024:
        try:
            os.remove(CHECKPOINT_DB)
        except OSError:
            pass


def main() -> None:
    _startup()
    yt_key, gem_key = secret("YOUTUBE_API_KEY"), secret("GEMINI_API_KEY")

    # Two sheets, not one: Streamlit truncates a single oversized HTML payload.
    st.markdown(theme.CSS, unsafe_allow_html=True)
    st.markdown(theme.CSS2, unsafe_allow_html=True)
    st.markdown(
        '<div class="cm-hero"><h1>Uptick<span class="cm-dot">.</span></h1>'
        '<p class="cm-tag">Find the creators your audience is talking about.</p>'
        '<p>Describe a campaign and get ranked YouTube creators worth '
        'approaching, with the sponsorship signals we could actually observe, '
        'a score breakdown, and a rationale checked against the source '
        'numbers.</p></div>',
        unsafe_allow_html=True,
    )

    # Quota is enforced (see the checks below and cache.quota_ledger) but is
    # deliberately NOT shown: it is an operator concern, and a meter counting
    # down only makes the user hesitate before searching.
    q = cache.quota_status()

    keys_ok = bool(yt_key and gem_key)
    if not keys_ok and not st.session_state.get("result"):
        st.markdown(
            '<div class="cm-banner warn"><b>API keys not configured.</b> '
            'Set <code>YOUTUBE_API_KEY</code> and <code>GEMINI_API_KEY</code> in '
            '<code>.streamlit/secrets.toml</code> to run live queries. You can '
            'explore the full interface right now with '
            '<b>See an example</b> below.</div>',
            unsafe_allow_html=True,
        )

    if q["blocked"]:
        st.markdown(
            '<div class="cm-banner warn"><b>New searches are paused for now.</b> '
            'Briefs you have already run still load instantly. Fresh searches '
            'will be available again shortly.</div>',
            unsafe_allow_html=True,
        )

    EXAMPLES = [
        "protein bar brand, India, Gen Z",
        "indie skincare label, UK, micro creators",
        "budget mechanical keyboards, US, tech audience",
    ]

    with st.form("brief_form"):
        brief = st.text_area(
            "Campaign brief",
            value=st.session_state.pop("prefill", ""),
            placeholder="protein bar brand, India, Gen Z\n\n"
                        "Name the product, the market, and who you want to reach.",
            height=110,
            label_visibility="collapsed",
        )
        c1, c2 = st.columns([1, 1])
        submitted = c1.form_submit_button(
            "Find creators", type="primary", use_container_width=True
        )
        sample = c2.form_submit_button(
            "See an example", use_container_width=True
        )

    if sample:
        st.session_state["result"] = demo_data.build()
        st.session_state["intent"] = st.session_state["result"]["intent"]
        st.rerun()

    # Example briefs, one click fills the box, so nobody faces a blank field.
    if not st.session_state.get("result"):
        cols = st.columns(len(EXAMPLES))
        for col, ex in zip(cols, EXAMPLES):
            if col.button(ex, key=f"ex_{ex}", use_container_width=True):
                st.session_state["prefill"] = ex
                st.rerun()

    standing_banners(st.session_state.get("intent"))

    if submitted:
        if not keys_ok:
            st.error(
                "Add YOUTUBE_API_KEY and GEMINI_API_KEY to "
                "`.streamlit/secrets.toml` to run a live query."
            )
            return
        if st.session_state.get("queries_run", 0) >= SESSION_QUERY_CAP:
            st.markdown(
                '<div class="cm-banner warn"><b>That is enough searches for '
                'this session.</b> Reload the page to start a new one.</div>',
                unsafe_allow_html=True,
            )
            return
        if not brief.strip():
            st.warning("Enter a brief first.")
            return

        st.session_state["queries_run"] = st.session_state.get("queries_run", 0) + 1
        with st.status("Starting…", expanded=True) as status:
            try:
                result = asyncio.run(run_query(brief, yt_key, gem_key, status))
                status.update(label="Done", state="complete", expanded=False)
            except Exception as e:
                status.update(label="Failed", state="error")
                st.exception(e)
                return
        st.session_state["result"] = result
        st.session_state["intent"] = result.get("intent")
        st.rerun()

    result = st.session_state.get("result")
    if not result:
        return

    if result.get("fatal"):
        st.markdown(
            f'<div class="cm-banner warn" style="border-left-color:var(--cm-bad)">'
            f'<b>{esc(result["fatal"])}</b></div>',
            unsafe_allow_html=True,
        )
        plan = result.get("query_plan") or {}
        if plan.get("search_keywords"):
            kws = "".join(chip(k) for k in plan["search_keywords"])
            st.markdown(
                '<div class="cm-sec" style="margin-top:1.2rem">Broader keywords to try</div>'
                f'<div class="cm-chips">{kws}</div>',
                unsafe_allow_html=True,
            )
        return

    srcs = result.get("cultural_sources") or []
    if srcs:
        st.markdown(
            '<div class="cm-note" style="margin-bottom:.9rem">'
            'Cultural research drew on: ' + esc(", ".join(srcs[:8])) + '</div>',
            unsafe_allow_html=True,
        )

    if result.get("demo"):
        st.markdown(
            '<div class="cm-banner"><b>Sample results.</b> Example creators, '
            'scored by the real ranking engine, the scores and breakdowns '
            'below are genuinely computed, not mocked up.</div>',
            unsafe_allow_html=True,
        )

    for n in dict.fromkeys(result.get("notices") or []):
        st.markdown(
            f'<div class="cm-banner warn">{esc(n)}</div>', unsafe_allow_html=True
        )

    intent = result.get("intent") or {}
    if intent.get("ambiguities"):
        items = "".join(f"<li>{esc(a)}</li>" for a in intent["ambiguities"])
        st.markdown(
            f'<div class="cm-banner"><b>The brief left some things open.</b>'
            f'<ul style="margin:.4rem 0 0;padding-left:1.1rem">{items}</ul>'
            f'<div style="margin-top:.4rem">Refining these will narrow the '
            f'results.</div></div>',
            unsafe_allow_html=True,
        )

    rows = graph_mod.apply_audit(
        result.get("scored") or [], result.get("rationales"), result.get("audit")
    )
    review = result.get("review_manually") or []
    excluded = result.get("excluded") or []

    if result.get("agent_failures"):
        failed = ", ".join(
            f.replace("_", " ") for f in sorted(set(result["agent_failures"]))
        )
        st.markdown(
            f'<div class="cm-banner warn"><b>Partial results.</b> These agents '
            f'failed and their weight was redistributed across the remaining '
            f'terms: {esc(failed)}. The ranking still stands on the measured '
            f'metrics.</div>',
            unsafe_allow_html=True,
        )

    if not rows and not review:
        st.markdown(
            '<div class="cm-banner warn"><b>No creators cleared the bar for '
            'this brief.</b> Rather than padding the list with weak matches, '
            'the result is empty, try a broader product term or a different '
            'region.</div>',
            unsafe_allow_html=True,
        )
        return

    top = rows[:15]
    short = (
        f' · only {len(top)} cleared the data-quality bar, and the list is '
        f'never padded to 15' if len(top) < 15 else ""
    )
    st.markdown(
        f'<div class="cm-sec" style="margin:1.6rem 0 .7rem">'
        f'{len(top)} ranked creator{"s" if len(top) != 1 else ""}{esc(short)}</div>',
        unsafe_allow_html=True,
    )
    if top and all(r["fit_score"] < 40 for r in top):
        st.markdown(
            '<div class="cm-banner warn"><b>Every candidate scored below 40.</b> '
            'This brief is probably a poor fit for the creators YouTube '
            'surfaced, treat these as weak leads rather than a shortlist.</div>',
            unsafe_allow_html=True,
        )

    for i, r in enumerate(top, 1):
        render_row(i, r)

    if review:
        st.markdown(
            f'<div class="cm-sec" style="margin:2rem 0 .5rem">'
            f'Review manually · {len(review)}</div>'
            '<div class="cm-banner warn" style="margin-bottom:.9rem">'
            'Flagged at high severity by the safety auditor. They are never '
            'silently dropped, a human decides.</div>',
            unsafe_allow_html=True,
        )
        for i, r in enumerate(review, 1):
            render_row(i, r)

    if excluded:
        with st.expander(f"Excluded before scoring · {len(excluded)}"):
            rows = "".join(
                f'<div class="cm-vid"><span>'
                f'{esc(e["channel"].get("snippet", {}).get("title", e["channel_id"]))}'
                f'</span><span class="n">{esc(e["exclusion"])}</span></div>'
                for e in excluded
            )
            st.markdown(rows, unsafe_allow_html=True)

    st.markdown("<div style='height:1.6rem'></div>", unsafe_allow_html=True)
    st.download_button(
        "Download results (JSON)",
        data=json.dumps(
            {"brief": st.session_state.get("intent"), "ranked": top,
             "review_manually": review},
            indent=2, default=str,
        ),
        file_name=f"uptick-{datetime.now():%Y%m%d-%H%M}.json",
        mime="application/json",
    )
    st.markdown(
        '<div class="cm-note" style="margin-top:1.4rem;border-top:1px solid '
        'var(--cm-border);padding-top:.9rem">'
        'Data via the official YouTube Data API v3. Country-level geography '
        'only · no audience demographics · engagement is a proxy, not '
        'predicted ROI · sponsorship disclosure is self-declared and '
        'under-reported.</div>',
        unsafe_allow_html=True,
    )


if __name__ == "__main__":
    main()
