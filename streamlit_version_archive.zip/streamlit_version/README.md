# Uptick — archived Streamlit interface

This is the original Streamlit UI, replaced by the FastAPI + React frontend
in the main project. Kept for reference only.

## Why it was replaced

Streamlit owns the DOM, which capped how far the design could go, and it
caused a real bug: a single `unsafe_allow_html` payload over roughly 18KB was
silently truncated in the browser, dropping every CSS rule after it with no
error. Splitting the stylesheet worked around it, but the ceiling remained.

## Files

- `app.py`   the whole interface: search, results, banners, progress
- `theme.py` the CSS design system and HTML component builders
- `.streamlit/config.toml` hides Streamlit's own developer toolbar

## Running it

It depends on the backend modules (`graph.py`, `agents.py`, `metrics.py`,
`youtube.py`, `cache.py`, `demo_data.py`) from the main project. Copy these
two files back into the project root, add `streamlit` to the environment, put
your keys in `.streamlit/secrets.toml`, then:

```bash
pip install streamlit
streamlit run app.py
```

Note: `app.py` reads keys through `st.secrets`, not environment variables.
The current API server reads both.
