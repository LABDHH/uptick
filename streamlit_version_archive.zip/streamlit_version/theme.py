"""Visual design system.

One place for the CSS and the HTML component builders, so app.py stays about
behavior. Everything here is theme-aware: colors are CSS variables redefined
under Streamlit's dark theme attribute, never hard-coded per component.
"""
from __future__ import annotations

import html

CSS = """
<style>
/* ---------------------------------------------------------------- tokens */
:root {
  --cm-bg:        #fbfbfd;
  --cm-surface:   #ffffff;
  --cm-raised:    #f4f5f8;
  --cm-border:    #e8eaef;
  --cm-border-sn: #d3d7e0;
  --cm-text:      #0d1220;
  --cm-muted:     #5c6579;
  --cm-faint:     #949cad;
  --cm-accent:    #4338ca;
  --cm-accent-sn: #eef0ff;
  --cm-good:      #067647;
  --cm-good-bg:   #ecfdf3;
  --cm-warn:      #b54708;
  --cm-warn-bg:   #fffaeb;
  --cm-bad:       #b42318;
  --cm-bad-bg:    #fef3f2;
  --cm-radius:    14px;
  --cm-shadow:    0 1px 2px rgba(16,24,40,.04), 0 1px 3px rgba(16,24,40,.06);
  --cm-shadow-lg: 0 4px 12px rgba(16,24,40,.06), 0 2px 4px rgba(16,24,40,.04);
}
@media (prefers-color-scheme: dark) {
  :root {
    --cm-bg:        #0b0e14;
    --cm-surface:   #141924;
    --cm-raised:    #1b212e;
    --cm-border:    #242b3a;
    --cm-border-sn: #333c4e;
    --cm-text:      #e9edf5;
    --cm-muted:     #9aa4b8;
    --cm-faint:     #6b7487;
    --cm-accent:    #a5b0fc;
    --cm-accent-sn: #1c2039;
    --cm-good:      #75e0a7;
    --cm-good-bg:   #0d2620;
    --cm-warn:      #fec84b;
    --cm-warn-bg:   #2b1f0a;
    --cm-bad:       #fda29b;
    --cm-bad-bg:    #2d1513;
    --cm-shadow:    none;
    --cm-shadow-lg: none;
  }
}

/* ---------------------------------------------------------------- layout */
.block-container { padding-top: 2.4rem; max-width: 1180px; }
#MainMenu, footer { visibility: hidden; }

/* Streamlit's own chrome, tuned to match */
div[data-testid="stExpander"] details {
  border: 1px solid var(--cm-border);
  border-radius: var(--cm-radius);
  background: var(--cm-surface);
  box-shadow: var(--cm-shadow);
  overflow: hidden;
}
div[data-testid="stExpander"] details summary { padding: .5rem .9rem; }
div[data-testid="stExpander"] details summary:hover { background: var(--cm-raised); }

.stButton > button, .stLinkButton > a, .stFormSubmitButton > button {
  border-radius: 9px !important;
  font-weight: 550 !important;
  letter-spacing: -.01em;
  transition: transform .06s ease, box-shadow .15s ease;
}
.stButton > button:active, .stFormSubmitButton > button:active { transform: translateY(1px); }
.stTextArea textarea, .stTextInput input {
  border-radius: 10px !important;
  border-color: var(--cm-border-sn) !important;
}
.stTextArea textarea:focus, .stTextInput input:focus {
  border-color: var(--cm-accent) !important;
  box-shadow: 0 0 0 3px var(--cm-accent-sn) !important;
}

/* ---------------------------------------------------------------- hero */
.cm-hero { margin: 0 0 1.6rem; }
.cm-hero h1 {
  font-size: 2.05rem; font-weight: 680; letter-spacing: -.035em;
  color: var(--cm-text); margin: 0 0 .35rem; line-height: 1.15;
}
.cm-hero p {
  font-size: .97rem; color: var(--cm-muted); margin: 0; max-width: 60ch;
  line-height: 1.5;
}
/* The tagline carries the brand; the paragraph under it explains the tool. */
.cm-hero p.cm-tag {
  font-size: 1.06rem; color: var(--cm-text); font-weight: 560;
  letter-spacing: -.018em; margin: 0 0 .5rem; max-width: 52ch;
}
.cm-hero .cm-dot { color: var(--cm-accent); }

/* ---------------------------------------------------------------- card */
.cm-card {
  border: 1px solid var(--cm-border);
  border-radius: var(--cm-radius);
  background: var(--cm-surface);
  padding: 1.05rem 1.15rem;
  box-shadow: var(--cm-shadow);
}
.cm-card + .cm-card { margin-top: .7rem; }

/* row header: rank · name · score */
.cm-rowhead { display: flex; align-items: center; gap: .85rem; width: 100%; }
.cm-rank {
  flex: none; width: 30px; height: 30px; border-radius: 8px;
  background: var(--cm-raised); color: var(--cm-muted);
  font-size: .82rem; font-weight: 650; font-variant-numeric: tabular-nums;
  display: flex; align-items: center; justify-content: center;
  border: 1px solid var(--cm-border);
}
.cm-rank.cm-top { background: var(--cm-accent); color: #fff; border-color: transparent; }
.cm-ident { min-width: 0; flex: 1; }
.cm-name {
  font-size: 1rem; font-weight: 620; color: var(--cm-text);
  letter-spacing: -.015em; white-space: nowrap; overflow: hidden;
  text-overflow: ellipsis; line-height: 1.3;
}
.cm-sub {
  font-size: .8rem; color: var(--cm-faint); margin-top: .1rem;
  font-variant-numeric: tabular-nums;
}

/* score */
.cm-score { flex: none; text-align: right; line-height: 1; }
.cm-score b {
  font-size: 1.5rem; font-weight: 680; color: var(--cm-text);
  letter-spacing: -.04em; font-variant-numeric: tabular-nums;
}
.cm-score span { font-size: .78rem; color: var(--cm-faint); font-weight: 500; }

/* score meter */
.cm-meter {
  height: 4px; border-radius: 99px; background: var(--cm-raised);
  overflow: hidden; margin-top: .5rem;
}
.cm-meter i { display: block; height: 100%; border-radius: 99px; background: var(--cm-accent); }

/* ---------------------------------------------------------------- chips */
.cm-chips { display: flex; flex-wrap: wrap; gap: .3rem; margin-top: .1rem; }
.cm-chip {
  display: inline-flex; align-items: center; gap: .25rem;
  font-size: .72rem; font-weight: 560; letter-spacing: .01em;
  padding: .14rem .45rem; border-radius: 6px;
  background: var(--cm-raised); color: var(--cm-muted);
  border: 1px solid var(--cm-border);
  white-space: nowrap;
}
.cm-chip.good { background: var(--cm-good-bg); color: var(--cm-good); border-color: transparent; }
.cm-chip.warn { background: var(--cm-warn-bg); color: var(--cm-warn); border-color: transparent; }
.cm-chip.bad  { background: var(--cm-bad-bg);  color: var(--cm-bad);  border-color: transparent; }
.cm-chip.accent { background: var(--cm-accent-sn); color: var(--cm-accent); border-color: transparent; }
.cm-chip i { font-style: normal; opacity: .75; }

/* ---------------------------------------------------------------- stats */
.cm-stats {
  display: grid; grid-template-columns: repeat(4, 1fr);
  gap: .55rem; margin: .9rem 0 .2rem;
}
@media (max-width: 720px) { .cm-stats { grid-template-columns: repeat(2, 1fr); } }
.cm-stat {
  background: var(--cm-raised); border: 1px solid var(--cm-border);
  border-radius: 10px; padding: .55rem .65rem;
}
.cm-stat .k {
  font-size: .68rem; text-transform: uppercase; letter-spacing: .06em;
  color: var(--cm-faint); font-weight: 600; margin-bottom: .2rem;
}
.cm-stat .v {
  font-size: 1.12rem; font-weight: 640; color: var(--cm-text);
  letter-spacing: -.025em; font-variant-numeric: tabular-nums; line-height: 1.2;
}
.cm-stat .v.dim { color: var(--cm-faint); font-weight: 500; font-size: .95rem; }

/* ---------------------------------------------------------------- prose */
.cm-quote {
  border-left: 2.5px solid var(--cm-accent);
  padding: .1rem 0 .1rem .8rem; margin: .2rem 0 .9rem;
}
.cm-quote .h {
  font-size: .97rem; font-weight: 620; color: var(--cm-text);
  letter-spacing: -.015em; margin-bottom: .22rem;
}
.cm-quote .b { font-size: .89rem; color: var(--cm-muted); line-height: 1.55; }
.cm-quote .c {
  font-size: .82rem; color: var(--cm-warn); margin-top: .35rem;
  display: flex; gap: .35rem; align-items: flex-start;
}

/* withheld / notice strip */
.cm-strip {
  font-size: .82rem; color: var(--cm-muted); background: var(--cm-raised);
  border: 1px dashed var(--cm-border-sn); border-radius: 9px;
  padding: .5rem .65rem; margin-bottom: .8rem; line-height: 1.45;
}

/* ---------------------------------------------------------------- bars */
.cm-sec {
  font-size: .69rem; text-transform: uppercase; letter-spacing: .07em;
  color: var(--cm-faint); font-weight: 650; margin: 0 0 .5rem;
}
.cm-bars { display: flex; flex-direction: column; gap: .34rem; }
.cm-bar { display: grid; grid-template-columns: 92px 1fr 40px; gap: .5rem; align-items: center; }
.cm-bar .l {
  font-size: .76rem; color: var(--cm-muted); text-align: right;
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
}
.cm-bar .t { height: 6px; border-radius: 99px; background: var(--cm-raised); overflow: hidden; }
.cm-bar .t i { display: block; height: 100%; border-radius: 99px; background: var(--cm-accent); opacity: .85; }
.cm-bar .p {
  font-size: .74rem; color: var(--cm-faint); text-align: right;
  font-variant-numeric: tabular-nums;
}

/* ---------------------------------------------------------------- evidence */
.cm-ev { display: flex; flex-direction: column; gap: .55rem; }
.cm-ev .row { font-size: .85rem; line-height: 1.5; }
.cm-ev .row .k {
  font-size: .68rem; text-transform: uppercase; letter-spacing: .06em;
  color: var(--cm-faint); font-weight: 640; display: block; margin-bottom: .1rem;
}
.cm-ev .row .v { color: var(--cm-muted); }
.cm-ev .row .v em { color: var(--cm-text); font-style: normal; font-weight: 560; }

/* video list */
.cm-vid {
  display: flex; align-items: baseline; gap: .5rem; padding: .32rem 0;
  border-top: 1px solid var(--cm-border); font-size: .84rem;
}
.cm-vid:first-of-type { border-top: none; }
.cm-vid a { color: var(--cm-text); text-decoration: none; flex: 1; min-width: 0;
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.cm-vid a:hover { color: var(--cm-accent); text-decoration: underline; }
.cm-vid .n { font-size: .78rem; color: var(--cm-faint); font-variant-numeric: tabular-nums; flex: none; }

/* ---------------------------------------------------------------- banner */
.cm-banner {
  border: 1px solid var(--cm-border); border-left: 3px solid var(--cm-accent);
  background: var(--cm-surface); border-radius: 10px;
  padding: .7rem .85rem; margin-bottom: .9rem;
  font-size: .83rem; color: var(--cm-muted); line-height: 1.55;
}
.cm-banner b { color: var(--cm-text); font-weight: 600; }
.cm-banner.warn { border-left-color: var(--cm-warn); }

/* sidebar */
section[data-testid="stSidebar"] { border-right: 1px solid var(--cm-border); }
.cm-q { margin-bottom: .85rem; }
.cm-q .k {
  font-size: .7rem; text-transform: uppercase; letter-spacing: .06em;
  color: var(--cm-faint); font-weight: 620; display: flex;
  justify-content: space-between; margin-bottom: .3rem;
}
.cm-q .k b { color: var(--cm-text); font-variant-numeric: tabular-nums; font-weight: 640; }
.cm-q .t { height: 5px; border-radius: 99px; background: var(--cm-raised); overflow: hidden; }
.cm-q .t i { display: block; height: 100%; border-radius: 99px; background: var(--cm-accent); }
.cm-q .t i.warn { background: var(--cm-warn); }
.cm-q .t i.bad { background: var(--cm-bad); }
.cm-note { font-size: .74rem; color: var(--cm-faint); line-height: 1.5; }

/* ---------------------------------------------------------------- refined */
html, body, [class*="css"] { -webkit-font-smoothing: antialiased; }
.stApp { background: var(--cm-bg); }
.block-container { padding-top: 2rem; padding-bottom: 4rem; max-width: 1100px; }

/* Streamlit expander -> looks like part of the card above it */
div[data-testid="stExpander"] { margin-top: -.55rem; }
div[data-testid="stExpander"] details {
  border: 1px solid var(--cm-border); border-top: none;
  border-radius: 0 0 var(--cm-radius) var(--cm-radius);
  background: var(--cm-surface); box-shadow: var(--cm-shadow);
}
div[data-testid="stExpander"] details summary {
  padding: .45rem 1.05rem; font-size: .78rem; color: var(--cm-faint);
  font-weight: 560;
}
div[data-testid="stExpander"] details summary:hover { color: var(--cm-accent); background: transparent; }
div[data-testid="stExpander"] details[open] summary { border-bottom: 1px solid var(--cm-border); }
div[data-testid="stExpanderDetails"] { padding: .2rem .25rem; }

/* card sits flush on top of its expander */
.cm-card.cm-joined { border-radius: var(--cm-radius) var(--cm-radius) 0 0; border-bottom: none; padding-bottom: .85rem; }

/* rank medal for the podium */
.cm-rank.cm-gold   { background: linear-gradient(145deg,#f5c451,#e0a020); color:#3d2c05; border-color:transparent; }
.cm-rank.cm-silver { background: linear-gradient(145deg,#dfe3ea,#b9c0cc); color:#2b313b; border-color:transparent; }
.cm-rank.cm-bronze { background: linear-gradient(145deg,#e4b184,#c68449); color:#3b2410; border-color:transparent; }

/* score colour follows quality */
.cm-score b.s-hi { color: var(--cm-good); }
.cm-score b.s-mid { color: var(--cm-text); }
.cm-score b.s-lo { color: var(--cm-faint); }

/* meter segments: base score vs bonuses */
.cm-meter { display:flex; height:5px; gap:2px; background:transparent; }
.cm-meter i { background: var(--cm-accent); }
.cm-meter i.bonus { background: var(--cm-good); opacity:.9; }
.cm-meter i.rest { background: var(--cm-raised); flex:1; }

/* section rhythm */
.cm-panel { margin-top: 1.1rem; }
.cm-panel:first-child { margin-top: .2rem; }

/* evidence rows as a definition grid */
.cm-ev .row { display:grid; grid-template-columns: 1fr; gap:.1rem; }

/* cultural block */
.cm-cult {
  border: 1px solid var(--cm-border); border-left: 3px solid var(--cm-good);
  background: var(--cm-raised); border-radius: 9px;
  padding: .6rem .75rem; margin-top: .7rem;
}
.cm-cult .t {
  font-size: .69rem; text-transform: uppercase; letter-spacing: .06em;
  font-weight: 650; color: var(--cm-good); margin-bottom: .25rem;
  display:flex; justify-content:space-between; align-items:center;
}
.cm-cult .b { font-size: .84rem; color: var(--cm-muted); line-height: 1.5; }
.cm-cult .b em { color: var(--cm-text); font-style: normal; font-weight: 560; }
.cm-src { font-size: .72rem; color: var(--cm-faint); margin-top: .4rem; }

/* empty / hero states */
.cm-empty {
  text-align:center; padding: 3rem 1rem; color: var(--cm-faint);
  border: 1px dashed var(--cm-border-sn); border-radius: var(--cm-radius);
  background: var(--cm-surface);
}
.cm-empty h3 { font-size: 1rem; color: var(--cm-text); margin: 0 0 .3rem; font-weight: 620; }
.cm-empty p { font-size: .87rem; margin: 0 auto; max-width: 46ch; line-height: 1.55; }

/* example brief pills */
.cm-ex { display:flex; flex-wrap:wrap; gap:.35rem; margin-top:.5rem; }

/* table-ish list for excluded */
.cm-vid span:first-child { flex:1; min-width:0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; color:var(--cm-muted); }

/* sidebar tightening */
section[data-testid="stSidebar"] .block-container { padding-top: 1.5rem; }
section[data-testid="stSidebar"] [data-testid="stVerticalBlock"] { gap: .4rem; }
</style>
"""

# A SECOND stylesheet, injected separately from CSS.
#
# Streamlit silently TRUNCATES a single very large unsafe_allow_html payload:
# a 22KB blob arrived at the browser cut to ~18KB, dropping the tail with no
# error anywhere. Splitting keeps later rules alive, and later rules are the
# ones that win the cascade.
CSS2 = """
<style>
/* ---------------------------------------------------------------- shell */
/* Centered column: this is a search tool, so it should read like a document
   rather than a dashboard. */
.block-container {
  max-width: 760px !important;
  padding-top: 3rem !important;
  margin-left: auto !important; margin-right: auto !important;
}
section[data-testid="stSidebar"], div[data-testid="collapsedControl"] { display: none !important; }
header[data-testid="stHeader"] { background: transparent; }

/* ---------------------------------------------------------------- hero */
.cm-hero { margin: 0 0 1.8rem; }
.cm-hero h1 {
  font-size: 2.7rem; font-weight: 700; letter-spacing: -.045em;
  line-height: 1.04; margin: 0 0 .5rem; color: var(--cm-text);
}
.cm-hero h1 .cm-dot { color: var(--cm-accent); }
.cm-hero p.cm-tag {
  font-size: 1.1rem; font-weight: 500; color: var(--cm-text);
  letter-spacing: -.02em; margin: 0 0 .5rem; opacity: .92; max-width: 52ch;
}
.cm-hero p { font-size: .91rem; color: var(--cm-muted); max-width: 60ch; line-height: 1.55; }

/* ---------------------------------------------------------------- search */
div[data-testid="stForm"] {
  border: none !important; padding: 0 !important;
  background: transparent !important; box-shadow: none !important;
}
.stTextArea textarea {
  font-size: 1rem !important; line-height: 1.55 !important;
  min-height: 112px !important; padding: .9rem 1rem !important;
  border-radius: 13px !important;
  border: 1px solid var(--cm-border-sn) !important;
  background: var(--cm-surface) !important;
  box-shadow: 0 1px 3px rgba(16,24,40,.05) !important;
  resize: none;
}
.stTextArea textarea:focus {
  border-color: var(--cm-accent) !important;
  box-shadow: 0 0 0 3px var(--cm-accent-sn) !important;
}
.stTextArea textarea::placeholder { color: var(--cm-faint); }

/* Example-brief pills */
.stButton > button {
  border-radius: 999px !important; font-size: .79rem !important;
  padding: .36rem .75rem !important; color: var(--cm-muted) !important;
  background: transparent !important;
  border: 1px solid var(--cm-border) !important;
}
.stButton > button:hover {
  border-color: var(--cm-accent) !important; color: var(--cm-accent) !important;
}

/* ---------------------------------------------------------------- cards */
.cm-card { border-radius: 16px; padding: 1.1rem 1.2rem .95rem; }
.cm-card.cm-joined { border-radius: 16px 16px 0 0; }
.cm-card:hover { border-color: var(--cm-border-sn); }
.cm-name { font-size: 1.05rem; font-weight: 640; letter-spacing: -.02em; }
.cm-sub { font-size: .79rem; }
.cm-score b { font-size: 1.7rem; letter-spacing: -.045em; }
.cm-score span { font-size: .72rem; }
.cm-rank { width: 26px; height: 26px; border-radius: 8px; font-size: .78rem; }
.cm-chip { font-size: .705rem; padding: .16rem .48rem; border-radius: 999px; }
.cm-stat { border-radius: 11px; }
.cm-sec { font-size: .66rem; letter-spacing: .09em; }
div[data-testid="stExpander"] details { border-radius: 0 0 16px 16px; }
div[data-testid="stExpander"] details summary { font-size: .76rem; }
div[data-testid="stExpander"] { margin-bottom: .85rem; }

/* The limits expander is a footnote, not a card. */
div[data-testid="stExpander"]:has(summary:first-line) details { }
.cm-banner.cm-fine {
  border: none; border-left: none; background: transparent;
  padding: .1rem 0; font-size: .8rem; color: var(--cm-muted); line-height: 1.55;
}

/* --------------------------------------------------------- PRIMARY BUTTON */
/* Confirmed from the live DOM: Streamlit emits kind="primaryFormSubmit".
   These rules sit in the second sheet so they load LAST and win. */
button[kind="primaryFormSubmit"] {
  background: var(--cm-accent) !important;
  border: 1px solid transparent !important;
  border-radius: 10px !important;
  box-shadow: 0 1px 2px rgba(67,56,202,.28) !important;
}
button[kind="primaryFormSubmit"] p,
button[kind="primaryFormSubmit"] div,
button[kind="primaryFormSubmit"] span {
  color: #ffffff !important; font-weight: 600 !important;
}
button[kind="primaryFormSubmit"]:hover { filter: brightness(1.12); }

button[kind="secondaryFormSubmit"] {
  background: var(--cm-surface) !important;
  border: 1px solid var(--cm-border-sn) !important;
  border-radius: 10px !important;
}
button[kind="secondaryFormSubmit"]:hover { border-color: var(--cm-accent) !important; }
button[kind="secondaryFormSubmit"] p { color: var(--cm-text) !important; }

@media (prefers-color-scheme: dark) {
  .cm-card { box-shadow: none; }
}
@media (max-width: 640px) {
  .block-container { padding-top: 2rem !important; padding-left: 1rem !important; padding-right: 1rem !important; }
  .cm-hero h1 { font-size: 2.05rem; }
  .cm-score b { font-size: 1.45rem; }
}
</style>
"""


# ---------------------------------------------------------------- helpers

def esc(s) -> str:
    return html.escape(str(s if s is not None else ""))


def chip(label: str, kind: str = "", icon: str = "") -> str:
    ic = f"<i>{esc(icon)}</i>" if icon else ""
    return f'<span class="cm-chip {kind}">{ic}{esc(label)}</span>'


def stat(label: str, value: str, dim: bool = False) -> str:
    cls = "v dim" if dim else "v"
    return (
        f'<div class="cm-stat"><div class="k">{esc(label)}</div>'
        f'<div class="{cls}">{esc(value)}</div></div>'
    )


def bar(label: str, frac: float, points: str) -> str:
    pct = max(0.0, min(1.0, frac)) * 100
    return (
        f'<div class="cm-bar"><div class="l">{esc(label)}</div>'
        f'<div class="t"><i style="width:{pct:.1f}%"></i></div>'
        f'<div class="p">{esc(points)}</div></div>'
    )


def ev_row(key: str, value_html: str) -> str:
    return f'<div class="row"><span class="k">{esc(key)}</span><span class="v">{value_html}</span></div>'
